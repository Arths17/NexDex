"""NexDex - Cross-System Business Impact Simulator"""

__version__ = "1.0.0"
__author__ = "NexDex Team"
